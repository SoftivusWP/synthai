<div class="grid-item swiper-slide">
    <a href="<?php echo esc_url($link);?>" <?php echo wp_kses_post($target);?>class="front<?php echo esc_attr( $backExists ); ?>"><img class="rs-grid-img <?php echo esc_attr( $animation ); ?>" <?php echo esc_attr( $show_tooltip );?> src="<?php echo esc_url( $image ); ?>"  ></a>                               
</div>  