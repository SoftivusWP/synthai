<div class="project-item-wrapper  ">
    <div class="project-item" >
        <a href="<?php echo get_the_permalink(); ?>" class="project-item-link">
            <span class="project-item-media"><?php the_post_thumbnail(); ?></span>
            <span class="project-item-title"><?php the_title(); ?></span>                      
        </a>  
    </div>
</div>