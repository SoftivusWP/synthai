<div class="grid-item <?php echo $termsString;?>">
<?php 
echo the_title() . 'masonary view' . '<br>'; ?>
</div>
