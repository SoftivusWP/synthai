<div class="grid-item <?php echo $termsString;?> ">
    <?php 
    echo the_title() . 'modern' . '<br>'; ?>
</div>
