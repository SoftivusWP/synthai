<?php
defined( 'ABSPATH' ) or exit;

class TPHF_Settings{
    public function __construct(){
        //
        
    }
}
